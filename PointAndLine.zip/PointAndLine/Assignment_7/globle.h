#pragma once
#include<iostream>
#include<math.h>
class globle
{
public:
	static float distance(float x1, float y1, float x2, float y2);
	static float calculateAreaOfTrangle(float a, float b, float c);

	static float circleRadius(float x1, float y1, float x2 = 0, float y2 = 0);
};

