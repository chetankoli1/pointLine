#pragma once

#include<iostream>
#include<math.h>
#include "coordinates.h"
#include "globle.h"

class Circle
{
public:
	static void checkPointInCircle(const CircleCoordinates& coordinates);
};

